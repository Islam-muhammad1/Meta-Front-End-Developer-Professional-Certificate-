// App.js
import React from 'react';
import './App.css';

const NavigationBar = () => {
  return (
    <div className="section navigation-bar">
      <div className="logo"></div>
      <nav>
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Menu</a>
        <a href="#">Reservations</a>
        <a href="#">Order Online</a>
        <a href="#">Login</a>
      </nav>
    </div>
  );
};

const HeroSection = () => {
  return (
    <div className="section hero-section">
      <div className="placeholder"></div>
      <div className="placeholder"></div>
      <div className="placeholder"></div>
      <button>Reserve a Table</button>
    </div>
  );
};

const Highlights = () => {
  return (
    <div className="section highlights">
      {[1, 2, 3].map((item) => (
        <div key={item} className="highlight-item">
          <div className="placeholder"></div>
          <p>Dish Name</p>
          <p>Description</p>
          <p>Price</p>
        </div>
      ))}
    </div>
  );
};

const Testimonials = () => {
  return (
    <div className="section testimonials">
      {[1, 2].map((item) => (
        <div key={item} className="placeholder"></div>
      ))}
    </div>
  );
};

const About = () => {
  return (
    <div className="section about">
      <div className="placeholder"></div>
      <div className="placeholder"></div>
    </div>
  );
};

const Footer = () => {
  return (
    <div className="section footer">
      <div className="placeholder"></div>
      <p>Contact Info</p>
      <p>Social Media Links</p>
    </div>
  );
};

const App = () => {
  return (
    <div className="container">
      <NavigationBar />
      <HeroSection />
      <Highlights />
      <Testimonials />
      <About />
      <Footer />
    </div>
  );
};

export default App;
